package com.storesnap.app

import android.content.ContentValues
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.moduleinstall.InstallStatusListener
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

private val Ink = Color(0xFF211A35)
private val Violet = Color(0xFF7653D6)
private val CanvasBg = Color(0xFFF7F5FB)
private val Muted = Color(0xFF777187)

private enum class WorkMode(val label: String, val detail: String) {
    REMOVE("Remove background", "Cut out the product"),
    COMPRESS("Compress only", "Keep the original background"),
    BOTH("Remove + compress", "StoreSync-ready product image")
}

private enum class PhotoState { READY, PROCESSING, SUCCESS, FAILED }
private data class PhotoEntry(
    val uri: Uri,
    val name: String,
    val id: String = uri.toString(),
    val state: PhotoState = PhotoState.READY,
    val outputUri: Uri? = null,
    val outputBytes: Long = 0L,
    val originalBytes: Long = 0L,
    val error: String? = null,
    val background: Int = AndroidColor.TRANSPARENT
)

private data class PaletteColor(val name: String, val hex: String)

private val palette = listOf(
    PaletteColor("White", "#FFFFFF"), PaletteColor("Black", "#000000"), PaletteColor("Charcoal", "#333333"),
    PaletteColor("Silver", "#C0C0C0"), PaletteColor("Grey", "#808080"), PaletteColor("Slate", "#708090"),
    PaletteColor("Red", "#FF0000"), PaletteColor("Crimson", "#DC143C"), PaletteColor("Coral", "#FF7F50"),
    PaletteColor("Orange", "#FFA500"), PaletteColor("Peach", "#FFE5B4"), PaletteColor("Amber", "#FFBF00"),
    PaletteColor("Yellow", "#FFFF00"), PaletteColor("Gold", "#FFD700"), PaletteColor("Cream", "#FFFDD0"),
    PaletteColor("Green", "#008000"), PaletteColor("Forest", "#228B22"), PaletteColor("Mint", "#98FF98"),
    PaletteColor("Olive", "#808000"), PaletteColor("Teal", "#008080"), PaletteColor("Cyan", "#00FFFF"),
    PaletteColor("Sky", "#87CEEB"), PaletteColor("Blue", "#0000FF"), PaletteColor("Navy", "#000080"),
    PaletteColor("Indigo", "#4B0082"), PaletteColor("Purple", "#800080"), PaletteColor("Violet", "#8F00FF"),
    PaletteColor("Lavender", "#E6E6FA"), PaletteColor("Pink", "#FFC0CB"), PaletteColor("Rose", "#FF007F"),
    PaletteColor("Magenta", "#FF00FF"), PaletteColor("Brown", "#8B4513"), PaletteColor("Chocolate", "#7B3F00"),
    PaletteColor("Beige", "#F5F5DC"), PaletteColor("Sand", "#C2B280"), PaletteColor("Transparent", "#00000000")
)

class MainActivity : ComponentActivity() {
    private var cameraUri: Uri? = null
    private var installListener: InstallStatusListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixoraApp() }
    }

    override fun onDestroy() {
        installListener?.let { ModuleInstall.getClient(this).unregisterListener(it) }
        super.onDestroy()
    }

    private fun requestSubjectModule(onState: (String, Float?, Boolean) -> Unit) {
        if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) != ConnectionResult.SUCCESS) {
            onState("Google Play services is missing, disabled, or needs updating. Update/enable Google Play services, then tap retry.", null, false)
            return
        }
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        val client = ModuleInstall.getClient(this)
        onState("Checking background-removal engine…", null, false)
        client.areModulesAvailable(segmenter)
            .addOnSuccessListener { availability ->
                if (availability.areModulesAvailable()) {
                    segmenter.close()
                    onState("Background-removal engine is ready", 1f, true)
                } else {
                    onState("Requesting required module…", null, false)
                    val listener = InstallStatusListener { update: ModuleInstallStatusUpdate ->
                        val progressInfo = update.progressInfo
                        val fraction = if (progressInfo != null && progressInfo.totalBytesToDownload > 0L) {
                            (progressInfo.bytesDownloaded.toFloat() / progressInfo.totalBytesToDownload.toFloat()).coerceIn(0f, 1f)
                        } else null
                        runOnUiThread {
                            when (update.installState) {
                                ModuleInstallStatusUpdate.InstallState.STATE_COMPLETED -> {
                                    onState("Background-removal engine is ready", 1f, true)
                                    client.unregisterListener(installListener ?: return@runOnUiThread)
                                    segmenter.close()
                                }
                                ModuleInstallStatusUpdate.InstallState.STATE_FAILED -> {
                                    onState("Module download failed. Check your connection and retry.", fraction, false)
                                    client.unregisterListener(installListener ?: return@runOnUiThread)
                                    segmenter.close()
                                }
                                ModuleInstallStatusUpdate.InstallState.STATE_CANCELED -> {
                                    onState("Module download was cancelled. Tap retry to continue.", fraction, false)
                                    client.unregisterListener(installListener ?: return@runOnUiThread)
                                    segmenter.close()
                                }
                                else -> onState("Downloading background-removal engine…", fraction, false)
                            }
                        }
                    }
                    installListener = listener
                    val request = ModuleInstallRequest.newBuilder().addApi(segmenter).setListener(listener).build()
                    client.installModules(request)
                        .addOnSuccessListener { response ->
                            if (response.areModulesAlreadyInstalled()) {
                                onState("Background-removal engine is ready", 1f, true)
                                client.unregisterListener(listener)
                                segmenter.close()
                            } else {
                                onState("Download requested. Waiting for Google Play services…", null, false)
                            }
                        }
                        .addOnFailureListener { error ->
                            onState("Could not start download: ${error.localizedMessage ?: "Google Play services unavailable"}", null, false)
                            client.unregisterListener(listener)
                            segmenter.close()
                        }
                }
            }
            .addOnFailureListener { error ->
                segmenter.close()
                onState("Could not check module: ${error.localizedMessage ?: "Check Google Play services and internet"}", null, false)
            }
    }

    private fun createCameraUri(): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "pixora_capture_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    }

    @Composable
    private fun PixoraApp() {
        val scope = rememberCoroutineScope()
        var moduleMessage by remember { mutableStateOf("Checking required components…") }
        var moduleProgress by remember { mutableStateOf<Float?>(null) }
        var moduleReady by remember { mutableStateOf(false) }
        var moduleStarted by remember { mutableStateOf(false) }
        var mode by remember { mutableStateOf(WorkMode.BOTH) }
        var applyToAll by remember { mutableStateOf(true) }
        var globalColor by remember { mutableIntStateOf(AndroidColor.TRANSPARENT) }
        var quality by remember { mutableFloatStateOf(88f) }
        var photos by remember { mutableStateOf(listOf<PhotoEntry>()) }
        var galleryPhotos by remember { mutableStateOf(listOf<PhotoEntry>()) }
        var working by remember { mutableStateOf(false) }
        var completedDialog by remember { mutableStateOf(false) }
        var selectedPreview by remember { mutableStateOf<PhotoEntry?>(null) }
        var tab by remember { mutableIntStateOf(0) }
        var totalSavedBytes by remember { mutableLongStateOf(0L) }
        var lastBatchCount by remember { mutableIntStateOf(0) }
        var currentBatchDone by remember { mutableIntStateOf(0) }
        var currentBatchTotal by remember { mutableIntStateOf(0) }
        var lastBatchSuccess by remember { mutableIntStateOf(0) }
        var lastBatchFailed by remember { mutableIntStateOf(0) }
        val busy = remember { AtomicBoolean(false) }

        fun startSetup(force: Boolean = false) {
            if ((!force && moduleStarted) || moduleReady) return
            moduleStarted = true
            requestSubjectModule { message, progress, ready ->
                moduleMessage = message
                moduleProgress = progress
                moduleReady = ready
                if (ready) moduleStarted = true
            }
        }

        LaunchedEffect(Unit) {
            startSetup()
            galleryPhotos = withContext(Dispatchers.IO) { querySavedPhotos() }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)) { uris ->
            if (uris.isNotEmpty()) {
                val existing = photos.map { it.id }.toSet()
                val added = uris.filterNot { it.toString() in existing }.mapIndexed { index, uri ->
                    PhotoEntry(uri, queryDisplayName(uri) ?: "Photo ${photos.size + index + 1}", background = globalColor)
                }
                photos = (photos + added).take(50)
                tab = 1
            }
        }
        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            val uri = cameraUri
            if (success && uri != null) {
                photos = (photos + PhotoEntry(uri, queryDisplayName(uri) ?: "Camera photo", background = globalColor)).take(50)
                tab = 1
            }
        }

        fun setPhotoColor(photoId: String, color: Int) {
            photos = photos.map { if (it.id == photoId) it.copy(background = color) else it }
        }

        fun beginProcessing() {
            if (working || photos.none { it.state == PhotoState.READY || it.state == PhotoState.FAILED }) return
            if (mode != WorkMode.COMPRESS && !moduleReady) {
                moduleMessage = "Background-removal engine is not ready. Download it before processing."
                startSetup()
                return
            }
            if (!busy.compareAndSet(false, true)) return
            working = true
            completedDialog = false
            scope.launch {
                val queue = photos.filter { it.state == PhotoState.READY || it.state == PhotoState.FAILED }
                lastBatchCount = queue.size
                currentBatchDone = 0
                currentBatchTotal = queue.size
                var finished = 0
                var successfulThisRun = 0
                var failedThisRun = 0
                queue.forEach { item ->
                    photos = photos.map { if (it.id == item.id) it.copy(state = PhotoState.PROCESSING, error = null) else it }
                    try {
                        val result = processOne(item, mode, if (applyToAll) globalColor else item.background, quality.toInt())
                        photos = photos.map { if (it.id == item.id) it.copy(state = PhotoState.SUCCESS, outputUri = result.first, outputBytes = result.second, originalBytes = result.third) else it }
                        totalSavedBytes += (result.third - result.second)
                        successfulThisRun++
                    } catch (e: Exception) {
                        photos = photos.map { if (it.id == item.id) it.copy(state = PhotoState.FAILED, error = e.cause?.localizedMessage ?: e.localizedMessage ?: "Processing failed") else it }
                        failedThisRun++
                    }
                    finished++
                    currentBatchDone = finished
                }
                lastBatchSuccess = successfulThisRun
                lastBatchFailed = failedThisRun
                working = false
                busy.set(false)
                completedDialog = true
            }
        }

        MaterialTheme(colorScheme = lightColorScheme(primary = Violet, onPrimary = Color.White, secondary = Ink, background = CanvasBg, surface = Color.White)) {
            Scaffold(
                containerColor = CanvasBg,
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 6.dp) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Collections, null) }, label = { Text("Batch") })
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.PhotoLibrary, null) }, label = { Text("Gallery") })
                        NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("PIXORA STUDIO", style = MaterialTheme.typography.labelSmall, color = Violet, fontWeight = FontWeight.Bold)
                            Text(when (tab) { 1 -> "Your batch"; 2 -> "Your gallery"; 3 -> "Preferences"; else -> "Make every photo\nstore-ready." }, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Ink, lineHeight = MaterialTheme.typography.headlineMedium.lineHeight)
                        }
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Violet), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Pixora", tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                    }

                    if (tab == 0 || tab == 3) {
                        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Ink), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Download, null, tint = Color(0xFFC7B7FF))
                                    Spacer(Modifier.width(8.dp))
                                    Text("BACKGROUND REMOVAL ENGINE", color = Color(0xFFC7B7FF), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Surface(color = if (moduleReady) Color(0xFF245D49) else Color(0xFF51436F), shape = CircleShape) {
                                        Text(if (moduleReady) "READY" else "SETUP", modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                                Text(moduleMessage, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                if (!moduleReady) {
                                    Text(moduleProgress?.let { "Download progress · ${(it * 100).toInt()}%" } ?: "Waiting for download progress…", color = Color(0xFFD7D0E7), style = MaterialTheme.typography.labelSmall)
                                    if (moduleProgress != null) LinearProgressIndicator(progress = { moduleProgress ?: 0f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFFBFAEFF), trackColor = Color(0xFF51436F))
                                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Color(0xFFBFAEFF), trackColor = Color(0xFF51436F))
                                    Text("Pixora requests the required Google ML Kit component automatically. An internet connection and Google Play services are required for the first download.", color = Color(0xFFD7D0E7), style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = { startSetup(force = true) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Check / retry download") }
                                } else Text("Installed on this phone. Background removal is ready to use offline.", color = Color(0xFFD7D0E7), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    when (tab) {
                        0 -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { cameraUri = createCameraUri(); cameraUri?.let { camera.launch(it) } }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(7.dp)); Text("Take photo") }
                                OutlinedButton(onClick = { picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(7.dp)); Text("Add photos") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                MetricCard("IN THIS BATCH", photos.size.toString(), Modifier.weight(1f))
                                MetricCard("COMPLETED", photos.count { it.state == PhotoState.SUCCESS }.toString(), Modifier.weight(1f))
                                MetricCard("FAILED", photos.count { it.state == PhotoState.FAILED }.toString(), Modifier.weight(1f))
                            }
                            SectionTitle("Choose your workflow", "Pick exactly what Pixora should do")
                            WorkMode.entries.forEach { option ->
                                val chosen = mode == option
                                Card(onClick = { mode = option }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (chosen) Color(0xFFF0EBFF) else Color.White), border = if (chosen) androidx.compose.foundation.BorderStroke(1.5.dp, Violet) else null) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(if (chosen) Violet else CanvasBg), contentAlignment = Alignment.Center) { Icon(Icons.Default.Tune, null, tint = if (chosen) Color.White else Muted) }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) { Text(option.label, fontWeight = FontWeight.SemiBold, color = Ink); Text(option.detail, style = MaterialTheme.typography.bodySmall, color = Muted) }
                                        RadioButton(selected = chosen, onClick = { mode = option }, colors = RadioButtonDefaults.colors(selectedColor = Violet))
                                    }
                                }
                            }
                            if (mode != WorkMode.COMPRESS) BackgroundControls(applyToAll, { applyToAll = it }, globalColor, { globalColor = it; if (it != AndroidColor.TRANSPARENT) photos = photos.map { p -> if (applyToAll) p.copy(background = it) else p } }, photos.size)
                            if (mode != WorkMode.REMOVE) {
                                SectionTitle("Compression quality", "Higher quality keeps more detail")
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Image quality", color = Ink, fontWeight = FontWeight.Medium); Text("${quality.toInt()}%", color = Violet, fontWeight = FontWeight.Bold) }
                                        Slider(value = quality, onValueChange = { quality = it }, valueRange = 45f..100f)
                                        Text("Recommended: 88% · Originals are never overwritten.", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            Button(onClick = { tab = 1 }, enabled = photos.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text("Review ${photos.size} photo(s)"); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.Collections, null) }
                        }
                        1 -> {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("${photos.size} / 50 selected", color = Muted, style = MaterialTheme.typography.labelLarge)
                                TextButton(onClick = { photos = emptyList() }, enabled = photos.isNotEmpty() && !working) { Icon(Icons.Default.DeleteOutline, null); Text("Clear") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddPhotoAlternate, null); Text("Add more") }
                                Button(onClick = { beginProcessing() }, enabled = photos.any { it.state == PhotoState.READY || it.state == PhotoState.FAILED } && !working, modifier = Modifier.weight(1f)) { Text(if (working) "Processing…" else "Start processing") }
                            }
                            if (working) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7FF)), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Text("Batch progress · $currentBatchDone of $currentBatchTotal", fontWeight = FontWeight.SemiBold, color = Ink); LinearProgressIndicator(progress = { if (currentBatchTotal == 0) 0f else currentBatchDone.toFloat() / currentBatchTotal }, modifier = Modifier.fillMaxWidth()) } }
                            }
                            if (photos.isEmpty()) EmptyState("No photos selected", "Add up to 50 product photos to begin.")
                            else LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 680.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
                                items(photos, key = { it.id }) { photo -> PhotoTile(photo, onClick = { selectedPreview = photo }, onRemove = { photos = photos.filterNot { it.id == photo.id } }) }
                            }
                        }
                        2 -> {
                            Text("Processed images are saved to Pictures/Pixora. Tap a photo to compare original and processed sizes.", color = Muted)
                            if (galleryPhotos.isEmpty()) EmptyState("Your gallery is waiting", "Successfully processed images will appear here.")
                            else LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp, max = 700.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
                                items(galleryPhotos, key = { it.id }) { PhotoTile(it, onClick = { selectedPreview = it }, onRemove = {}) }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text("Net storage saved this session", color = Muted); Text(formatSignedBytes(totalSavedBytes), color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } }
                        }
                        3 -> {
                            SectionTitle("App preferences", "Your defaults for future batches")
                            BackgroundControls(applyToAll, { applyToAll = it }, globalColor, { globalColor = it }, photos.size)
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Output folder", fontWeight = FontWeight.SemiBold, color = Ink); Text("Pictures/Pixora", color = Muted); Text("Format: WebP · Original files remain unchanged", color = Muted, style = MaterialTheme.typography.bodySmall) } }
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("About Pixora", fontWeight = FontWeight.SemiBold, color = Ink); Text("A private, on-device product image studio designed to prepare photos for StoreSync.", color = Muted); Text("Version 2.0 · No account required · No image uploads", color = Muted, style = MaterialTheme.typography.bodySmall) } }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        if (completedDialog) {
            val success = lastBatchSuccess
            val failed = lastBatchFailed
            AlertDialog(onDismissRequest = { completedDialog = false }, icon = { Icon(Icons.Default.CheckCircle, null, tint = Violet, modifier = Modifier.size(36.dp)) }, title = { Text(if (failed == 0) "All photos are ready!" else "Batch finished") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Your images have been processed."); Text("$success successful · $failed failed · $lastBatchCount attempted", fontWeight = FontWeight.SemiBold); Text("Saved in Pictures/Pixora", color = Muted) } }, confirmButton = { TextButton(onClick = { completedDialog = false; tab = if (failed > 0) 1 else 2 }) { Text(if (failed > 0) "Review / retry" else "View gallery") } }, dismissButton = { TextButton(onClick = { completedDialog = false }) { Text("Close") } })
        }

        selectedPreview?.let { preview ->
            AlertDialog(onDismissRequest = { selectedPreview = null }, title = { Text(preview.name, maxLines = 1, overflow = TextOverflow.Ellipsis) }, text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val originalPreview = rememberBitmap(preview.uri)
                    val processedPreview = preview.outputUri?.let { rememberBitmap(it) }
                    if (preview.state == PhotoState.SUCCESS && originalPreview != null && processedPreview != null) {
                        Text("BEFORE", style = MaterialTheme.typography.labelSmall, color = Muted)
                        Image(originalPreview.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).clip(RoundedCornerShape(12.dp)))
                        Text("AFTER", style = MaterialTheme.typography.labelSmall, color = Muted)
                        Image(processedPreview.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(12.dp)))
                    } else if (originalPreview != null) Image(originalPreview.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp).clip(RoundedCornerShape(12.dp)))
                    Text("Status: ${preview.state.name.lowercase().replaceFirstChar { it.uppercase() }}", color = Muted)
                    preview.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    if (preview.state == PhotoState.SUCCESS) {
                        Text("Original · ${formatBytes(preview.originalBytes)}", color = Muted)
                        Text("Processed · ${formatBytes(preview.outputBytes)}", color = Violet)
                        Text(if (preview.originalBytes > preview.outputBytes) "Saved · ${formatBytes(preview.originalBytes - preview.outputBytes)} (${((preview.originalBytes - preview.outputBytes) * 100.0 / preview.originalBytes).toInt()}% smaller)" else if (preview.originalBytes > 0L) "${formatBytes(preview.outputBytes - preview.originalBytes)} larger than original" else "Original file size unavailable", color = if (preview.originalBytes > preview.outputBytes) Color(0xFF16834A) else Color(0xFFB42318))
                    }
                    if (preview.state != PhotoState.SUCCESS && mode != WorkMode.COMPRESS) {
                        Text("Background colour", fontWeight = FontWeight.SemiBold)
                        ColorPalette(preview.background) { c -> setPhotoColor(preview.id, c); selectedPreview = preview.copy(background = c) }
                    }
                }
            }, confirmButton = { TextButton(onClick = { selectedPreview = null }) { Text("Done") } }, dismissButton = { if (preview.state == PhotoState.FAILED) TextButton(onClick = { selectedPreview = null; beginProcessing() }) { Text("Retry batch") } })
        }
    }

    @Composable
    private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
        Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(13.dp)) { Text(value, color = Ink, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text(label, color = Muted, style = MaterialTheme.typography.labelSmall) } }
    }

    @Composable
    private fun SectionTitle(title: String, subtitle: String) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text(title, color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall) }
    }

    @Composable
    private fun EmptyState(title: String, subtitle: String) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.AddPhotoAlternate, null, tint = Violet, modifier = Modifier.size(38.dp)); Text(title, color = Ink, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted) } }
    }

    @Composable
    private fun BackgroundControls(applyAll: Boolean, onApplyAll: (Boolean) -> Unit, selectedColor: Int, onColor: (Int) -> Unit, photoCount: Int) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("Background colour", "Choose one colour for the batch or set each photo separately")
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Apply to all photos", color = Ink, fontWeight = FontWeight.SemiBold); Text("Use one colour for all $photoCount selected images", color = Muted, style = MaterialTheme.typography.bodySmall) }
                        Switch(checked = applyAll, onCheckedChange = onApplyAll)
                    }
                    Text(if (applyAll) "Batch colour" else "Default colour · You can change each photo in Batch", color = Ink, fontWeight = FontWeight.Medium)
                    ColorPalette(selectedColor, onColor)
                    Text("Includes standard colours, popular shades and transparent output. Use custom HEX to enter any colour.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    @Composable
    private fun ColorPalette(selected: Int, onSelect: (Int) -> Unit) {
        var customHex by remember { mutableStateOf("#7653D6") }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LazyVerticalGrid(columns = GridCells.Fixed(6), modifier = Modifier.fillMaxWidth().height(184.dp), userScrollEnabled = true, verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(palette) { color ->
                    val parsed = try { AndroidColor.parseColor(color.hex) } catch (_: Exception) { AndroidColor.WHITE }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelect(parsed) }) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(if (color.name == "Transparent") Color(0xFFEAE7F0) else Color(parsed)).border(if (selected == parsed) 3.dp else 1.dp, if (selected == parsed) Violet else Color(0xFFE3DFEA), CircleShape), contentAlignment = Alignment.Center) {
                            if (color.name == "Transparent") Text("∅", color = Ink)
                            else if (selected == parsed) Icon(Icons.Default.CheckCircle, null, tint = if (parsed == AndroidColor.WHITE || parsed == AndroidColor.YELLOW) Ink else Color.White, modifier = Modifier.size(18.dp))
                        }
                        Text(color.name, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                    }
                }
            }
            val hsv = FloatArray(3).also { AndroidColor.colorToHSV(selected, it) }
            var hue by remember(selected) { mutableFloatStateOf(hsv[0]) }
            var saturation by remember(selected) { mutableFloatStateOf(hsv[1]) }
            var brightness by remember(selected) { mutableFloatStateOf(hsv[2]) }
            val spectrumColor = AndroidColor.HSVToColor(floatArrayOf(hue, saturation, brightness))
            Text("Full-spectrum colour picker", color = Ink, fontWeight = FontWeight.SemiBold)
            Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(10.dp)).background(Color(spectrumColor)))
            Text("Hue", color = Muted, style = MaterialTheme.typography.labelSmall)
            Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f)
            Text("Saturation", color = Muted, style = MaterialTheme.typography.labelSmall)
            Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..1f)
            Text("Brightness", color = Muted, style = MaterialTheme.typography.labelSmall)
            Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0f..1f)
            OutlinedButton(onClick = { onSelect(spectrumColor) }, modifier = Modifier.fillMaxWidth()) { Text("Apply custom colour") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = customHex, onValueChange = { customHex = it }, label = { Text("Custom HEX colour") }, singleLine = true, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Button(onClick = { try { onSelect(AndroidColor.parseColor(customHex.trim())) } catch (_: Exception) { } }, shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Palette, null) }
            }
        }
    }

    @Composable
    private fun PhotoTile(photo: PhotoEntry, onClick: () -> Unit, onRemove: () -> Unit) {
        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
            Column {
                val bmp = rememberBitmap(photo.outputUri ?: photo.uri)
                Box(Modifier.fillMaxWidth().height(132.dp).background(Color(0xFFECEAF0)), contentAlignment = Alignment.Center) {
                    if (bmp != null) Image(bmp.asImageBitmap(), null, modifier = Modifier.fillMaxSize()) else Icon(Icons.Default.Image, null, tint = Muted, modifier = Modifier.size(32.dp))
                    if (photo.state == PhotoState.PROCESSING) CircularProgressIndicator(modifier = Modifier.size(28.dp), color = Violet)
                    if (photo.state == PhotoState.SUCCESS) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF16834A), modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(24.dp))
                    if (photo.state == PhotoState.FAILED) Surface(color = Color(0xFFB42318), shape = RoundedCornerShape(6.dp), modifier = Modifier.align(Alignment.TopEnd).padding(7.dp)) { Text("FAILED", color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall) }
                }
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(photo.name, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium); Text(photo.state.name.lowercase().replaceFirstChar { it.uppercase() }, color = when (photo.state) { PhotoState.SUCCESS -> Color(0xFF16834A); PhotoState.FAILED -> Color(0xFFB42318); else -> Muted }, style = MaterialTheme.typography.labelSmall) }
                    if (photo.state == PhotoState.READY || photo.state == PhotoState.FAILED) IconButton(onClick = onRemove, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.DeleteOutline, null, tint = Muted, modifier = Modifier.size(18.dp)) }
                }
            }
        }
    }

    private suspend fun processOne(item: PhotoEntry, mode: WorkMode, background: Int, quality: Int): Triple<Uri, Long, Long> = withContext(Dispatchers.IO) {
        val originalBytes = contentResolver.openAssetFileDescriptor(item.uri, "r")?.use { it.length }?.takeIf { it > 0L } ?: queryFileSize(item.uri)
        val original = contentResolver.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalArgumentException("Could not read image")
        val resultBitmap = try {
            if (mode == WorkMode.COMPRESS) original.copy(Bitmap.Config.ARGB_8888, true)
            else {
                val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
                val segmenter = SubjectSegmentation.getClient(options)
                try {
                    val result = Tasks.await(segmenter.process(InputImage.fromBitmap(original, 0)))
                    val foreground = result.foregroundBitmap ?: throw IllegalStateException("No foreground detected")
                    val cutout = if (background == AndroidColor.TRANSPARENT) foreground.copy(Bitmap.Config.ARGB_8888, true)
                    else Bitmap.createBitmap(foreground.width, foreground.height, Bitmap.Config.ARGB_8888).also { output ->
                        val canvas = Canvas(output)
                        canvas.drawColor(background)
                        canvas.drawBitmap(foreground, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    }
                    if (foreground !== cutout && !foreground.isRecycled) foreground.recycle()
                    cutout
                } finally { segmenter.close() }
            }
        } finally { if (!original.isRecycled) original.recycle() }

        val base = item.name.substringBeforeLast('.', item.name).replace(Regex("[^A-Za-z0-9_-]"), "_").take(50).ifBlank { "product" }
        val fileName = "${base}_pixora_${System.currentTimeMillis()}.webp"
        val tempFile = File(cacheDir, "${fileName}.tmp")
        var encodedQuality = quality.coerceIn(45, 100)
        val format = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
        try {
            // Transparent WebP can also be lossy. Lossless encoding was making cut-outs
            // unnecessarily large and ignored the user's quality setting.
            do {
                FileOutputStream(tempFile, false).use { stream ->
                    if (!resultBitmap.compress(format, encodedQuality, stream)) throw IllegalStateException("WebP compression failed")
                    stream.flush()
                }
                // If the result is still larger than the source, retry at a lower quality.
                // Stop at 45 to avoid destroying product detail just to force a smaller file.
                if (originalBytes <= 0L || tempFile.length() <= originalBytes || encodedQuality <= 45) break
                encodedQuality = (encodedQuality - 8).coerceAtLeast(45)
            } while (true)

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/webp")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pixora")
            }
            val outUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create output file")
            try {
                contentResolver.openOutputStream(outUri)?.use { output -> tempFile.inputStream().use { input -> input.copyTo(output) } }
                    ?: throw IllegalStateException("Could not save output")
                val bytes = contentResolver.openAssetFileDescriptor(outUri, "r")?.use { it.length }?.takeIf { it > 0L } ?: tempFile.length()
                Triple(outUri, bytes, originalBytes)
            } catch (e: Exception) {
                contentResolver.delete(outUri, null, null)
                throw e
            }
        } finally {
            tempFile.delete()
            if (!resultBitmap.isRecycled) resultBitmap.recycle()
        }
    }

    @Composable
    private fun rememberBitmap(uri: Uri): Bitmap? {
        val bitmap by produceState<Bitmap?>(initialValue = null, key1 = uri) {
            value = withContext(Dispatchers.IO) { loadPreview(uri) }
        }
        return bitmap
    }

    private fun loadPreview(uri: Uri): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val largest = maxOf(bounds.outWidth, bounds.outHeight)
        val sample = if (largest > 900) (largest / 900).coerceAtLeast(1) else 1
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    } catch (_: Exception) { null }

    private fun querySavedPhotos(): List<PhotoEntry> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return emptyList()
        val results = mutableListOf<PhotoEntry>()
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE)
        val selection = "${MediaStore.Images.Media.RELATIVE_PATH} = ? OR ${MediaStore.Images.Media.RELATIVE_PATH} = ?"
        try {
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, arrayOf("Pictures/Pixora/", "Pictures/StoreSnap/"), "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                while (cursor.moveToNext()) {
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cursor.getLong(idIndex))
                    val name = cursor.getString(nameIndex) ?: "Pixora image"
                    val size = cursor.getLong(sizeIndex)
                    results.add(PhotoEntry(uri, name, state = PhotoState.SUCCESS, outputUri = uri, outputBytes = size))
                }
            }
        } catch (_: Exception) { }
        return results
    }

    private fun queryFileSize(uri: Uri): Long = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(cursor.getColumnIndexOrThrow(OpenableColumns.SIZE)).takeIf { it > 0L } ?: 0L else 0L
        } ?: 0L
    } catch (_: Exception) { 0L }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    } catch (_: Exception) { null }

    private fun formatBytes(bytes: Long): String {
        val df = DecimalFormat("0.##")
        val absolute = kotlin.math.abs(bytes)
        return if (absolute >= 1024L * 1024L) "${df.format(absolute / (1024.0 * 1024.0))} MB" else "${df.format(absolute / 1024.0)} KB"
    }

    private fun formatSignedBytes(bytes: Long): String = when {
        bytes > 0L -> "${formatBytes(bytes)} saved"
        bytes < 0L -> "${formatBytes(bytes)} extra used"
        else -> "0 KB saved"
    }
}
