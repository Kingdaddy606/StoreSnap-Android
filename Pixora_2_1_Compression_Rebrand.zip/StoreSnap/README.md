# Pixora Android

Pixora takes a photo or selects up to 50 images, removes the background with the on-device ML Kit Subject Segmentation API, compresses the foreground as transparent WebP, and saves results to `Pictures/Pixora`.

## Build
Open this project in Android Studio, or build with Java 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

The GitHub Actions workflow is supplied as `GITHUB_ACTIONS_WORKFLOW.txt`. Copy its workflow YAML into `.github/workflows/build-pixora.yml` in the repository that contains `Pixora_Android_Project.zip`.

## Compatibility
The StoreSync project checked for this app accepts `image/jpeg`, `image/png`, `image/webp`, and `image/heic` in the `product-images` Supabase bucket, with a 5 MiB maximum upload size. Pixora exports `image/webp`.

## Model note
ML Kit Subject Segmentation can require Google Play services to download its model on first use. Once downloaded, processing is on-device. Test first-use model availability on the target phone before relying on fully offline operation.


## Branding included in v3
- Custom Pixora launcher icon for the installed APK and app drawer.
- Matching launch splash icon on Android 12+ and a compatible launch background on earlier Android versions.


## Pixora 2.0
- Modern Studio-style interface with Home, Batch, Gallery, and Settings tabs.
- Batch selection of up to 50 photos, with individual previews and per-photo status.
- Remove background, compress only, or both.
- Transparent output or a shared/per-photo background colour.
- Named colour palette, HSV full-spectrum picker, and custom HEX input.
- WebP output to Pictures/Pixora; originals are never overwritten.
- First-launch ML Kit subject-segmentation module check and explicit installation request with progress reporting.
- Batch completion summary, failed-photo retry, and quality setting.

The ML Kit subject-segmentation model is delivered by Google Play services. First use requires internet and compatible Google Play services; the app cannot force Google services to complete a download if the device or service blocks it.
