package com.storesnap.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private var cameraUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoreSnapScreen() }
    }

    private fun createCameraUri(): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "storesnap_capture_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    }

    @Composable
    private fun StoreSnapScreen() {
        val scope = rememberCoroutineScope()
        var status by remember { mutableStateOf("Ready. Choose a photo or take a picture.") }
        var working by remember { mutableStateOf(false) }
        var done by remember { mutableIntStateOf(0) }
        var total by remember { mutableIntStateOf(0) }
        var saved by remember { mutableIntStateOf(0) }
        var savedBytes by remember { mutableLongStateOf(0L) }
        var errors by remember { mutableStateOf(listOf<String>()) }
        val busy = remember { AtomicBoolean(false) }

        val multiPicker = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
        ) { uris ->
            if (uris.isNotEmpty()) {
                scope.launch {
                    if (!busy.compareAndSet(false, true)) return@launch
                    working = true; done = 0; total = uris.size; saved = 0; savedBytes = 0L; errors = emptyList()
                    status = "Preparing ${uris.size} image(s)…"
                    try {
                        val result = processBatch(uris) { finished, count, outputBytes, failures, message ->
                            done = finished; total = count; saved = finished - failures.size
                            savedBytes = outputBytes; errors = failures; status = message
                        }
                        status = "Finished: ${result.first} saved${if (result.second > 0) ", ${result.second} failed" else ""}."
                    } catch (e: Exception) {
                        status = "Could not finish: ${e.message ?: "unknown error"}"
                    } finally { working = false; busy.set(false) }
                }
            }
        }

        val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            val uri = cameraUri
            if (success && uri != null) {
                scope.launch {
                    if (!busy.compareAndSet(false, true)) return@launch
                    working = true; done = 0; total = 1; saved = 0; savedBytes = 0L; errors = emptyList()
                    try {
                        val result = processBatch(listOf(uri)) { finished, count, outputBytes, failures, message ->
                            done = finished; total = count; saved = finished - failures.size; savedBytes = outputBytes; errors = failures; status = message
                        }
                        status = "Finished: ${result.first} saved${if (result.second > 0) ", ${result.second} failed" else ""}."
                    } catch (e: Exception) { status = "Could not finish: ${e.message ?: "unknown error"}" }
                    finally { working = false; busy.set(false) }
                }
            } else status = "Picture cancelled."
        }

        MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF111827), background = Color(0xFFF8FAFC))) {
            Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF8FAFC)) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("StoreSnap", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("Remove backgrounds. Compress. Save for StoreSync.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            cameraUri = createCameraUri()
                            val uri = cameraUri
                            if (uri != null) cameraLauncher.launch(uri) else status = "Could not open the camera."
                        }, enabled = !working, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Take photo")
                        }
                        OutlinedButton(onClick = { multiPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, enabled = !working, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Collections, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Select up to 50")
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (working) "Processing images" else "Status", fontWeight = FontWeight.SemiBold)
                            Text(status, style = MaterialTheme.typography.bodyMedium)
                            if (working) LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                            if (total > 0) Text("Processed $done of $total · Saved $saved", color = Color(0xFF475569))
                            if (savedBytes > 0) Text("Output size: ${formatBytes(savedBytes)}", color = Color(0xFF047857), fontWeight = FontWeight.Medium)
                        }
                    }
                    Text("How it works", fontWeight = FontWeight.SemiBold)
                    Text("Images are processed on this phone and saved in Pictures/StoreSnap as transparent WebP files. Original images are left unchanged.", color = Color(0xFF475569), style = MaterialTheme.typography.bodyMedium)
                    Text("Note: the background-removal model may need internet once to download before first use. After the model is available, image processing runs on-device.", color = Color(0xFF64748B), style = MaterialTheme.typography.bodySmall)
                    if (errors.isNotEmpty()) {
                        Text("Images that need retrying", fontWeight = FontWeight.SemiBold, color = Color(0xFFB91C1C))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) { items(errors) { Text("• $it", style = MaterialTheme.typography.bodySmall, color = Color(0xFFB91C1C)) } }
                    }
                    Spacer(Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF64748B))
                        Spacer(Modifier.width(8.dp))
                        Text("Output: Pictures/StoreSnap · WebP · transparent background", style = MaterialTheme.typography.labelMedium, color = Color(0xFF64748B))
                    }
                }
            }
        }
    }

    private suspend fun processBatch(
        uris: List<Uri>,
        onProgress: (finished: Int, total: Int, outputBytes: Long, failures: List<String>, message: String) -> Unit
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        var successes = 0
        var bytesTotal = 0L
        val failures = mutableListOf<String>()
        try {
            uris.forEachIndexed { index, uri ->
                val name = queryDisplayName(uri) ?: "image_${index + 1}"
                try {
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                        ?: throw IllegalArgumentException("Could not read image")
                    val input = InputImage.fromBitmap(bitmap, 0)
                    val result = Tasks.await(segmenter.process(input))
                    val foreground = result.foregroundBitmap ?: throw IllegalStateException("No foreground detected")
                    val output = saveWebp(foreground, name)
                    bytesTotal += output
                    successes++
                    if (foreground !== bitmap && !foreground.isRecycled) foreground.recycle()
                    if (!bitmap.isRecycled) bitmap.recycle()
                } catch (e: Exception) {
                    failures.add("$name: ${e.cause?.message ?: e.message ?: "processing failed"}")
                }
                onProgress(index + 1, uris.size, bytesTotal, failures.toList(), "Processing ${index + 1} of ${uris.size}…")
            }
        } finally { segmenter.close() }
        Pair(successes, failures.size)
    }

    private fun saveWebp(bitmap: Bitmap, originalName: String): Long {
        val base = originalName.substringBeforeLast('.', originalName).replace(Regex("[^A-Za-z0-9_-]"), "_").take(60).ifBlank { "product" }
        val displayName = "${base}_storesnap_${System.currentTimeMillis()}.webp"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/webp")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/StoreSnap")
        }
        val outUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create output file")
        try {
            contentResolver.openOutputStream(outUri)?.use { stream ->
                val format = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                if (!bitmap.compress(format, 88, stream)) throw IllegalStateException("WebP compression failed")
            } ?: throw IllegalStateException("Could not save output file")
            return contentResolver.openFileDescriptor(outUri, "r")?.use { it.statSize }?.coerceAtLeast(0) ?: 0L
        } catch (e: Exception) {
            contentResolver.delete(outUri, null, null)
            throw e
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun formatBytes(bytes: Long): String {
        val df = DecimalFormat("0.##")
        return when { bytes >= 1024L * 1024L -> "${df.format(bytes / (1024.0 * 1024.0))} MB"; else -> "${df.format(bytes / 1024.0)} KB" }
    }
}
