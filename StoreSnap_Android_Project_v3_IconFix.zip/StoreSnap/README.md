# StoreSnap Android

StoreSnap takes a photo or selects up to 50 images, removes the background with the on-device ML Kit Subject Segmentation API, compresses the foreground as transparent WebP, and saves results to `Pictures/StoreSnap`.

## Build
Open this project in Android Studio, or build with Java 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

The GitHub Actions workflow is supplied as `GITHUB_ACTIONS_WORKFLOW.txt`. Copy its workflow YAML into `.github/workflows/build-storesnap.yml` in the repository that contains `StoreSnap_Android_Project.zip`.

## Compatibility
The StoreSync project checked for this app accepts `image/jpeg`, `image/png`, `image/webp`, and `image/heic` in the `product-images` Supabase bucket, with a 5 MiB maximum upload size. StoreSnap exports `image/webp`.

## Model note
ML Kit Subject Segmentation can require Google Play services to download its model on first use. Once downloaded, processing is on-device. Test first-use model availability on the target phone before relying on fully offline operation.


## Branding included in v3
- Custom StoreSnap launcher icon for the installed APK and app drawer.
- Matching launch splash icon on Android 12+ and a compatible launch background on earlier Android versions.
